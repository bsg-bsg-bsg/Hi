-- Saved by UniversalSynSaveInstance (Join to Copy Games) https://discord.gg/wx4ThpAsmw

-- Decompiler will be improved VERY SOON!
-- Decompiled with Konstant V2.1, a fast Luau decompiler made in Luau by plusgiant5 (https://discord.gg/brNTY8nX8t)
-- Decompiled on 2025-07-23 21:50:29
-- Luau version 6, Types version 3
-- Time taken: 0.000956 seconds

return {{
	heading = "Game design / development";
	credits = {"Josh Sheldon - jshel.co", ""};
}, {
	heading = "Icon / thumbnail graphics";
	credits = {"RandomFlowz", ""};
}, {
	heading = "Music";
	credits = {"Kevin MacLeod - incompetech.com", "Frank Nora - mcs.franknora.com", ""};
}, {
	heading = "Sound Effects";
	credits = {"Mike Koenig - soundbible.com", "Roblox user Nexx", "Roblox user DTF", "", ""};
}, {
	heading = "With retexture and model contributions by:";
	credits = {"Unikarnz", "Jac16king", "Fjalon", "Trainsparency", "Jerricks", "SMALLSOPE42", "Mehdamorphis", "Jimkulus", "Ewnceladus", "Smatchet", "ElectroTechnologies", "Tri_angulum", "RandomFlowz", "Axivele", "TC1010tiago", "cars95mate", "Endervene", "", ""};
}, {
	heading = "Volunteer translations by:";
	credits = {"NitroretroOfficial - Romanian", "@iniciantinroblox (Mr_Tower) - Portugese"};
}, {
	heading = "Special thanks to the following Roblox users:";
	credits = {"EpikYummeh", "SatansNoob", "CeIesti", "man2222222222", "Khanovich", "Quenty", "Rukiryo", "Gusmanak", "Zolarketh"};
}}